# Range-Calculator

front-end website to calculate range of battery
